`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/14/2026 07:42:27 AM
// Design Name: Nguyen Duc Toan
// Module Name: Data_memory
// Project Name: RV32I
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
///////////////////////////////////////////////////////////////////////////

module Data_memory(
    input logic clk,
    input logic we,
    input logic [31:0] A,
    input logic [31:0] wd,
    input logic [2:0] funct3,
    output logic [31:0] RD
);

    logic [31:0] RAM[16383:0];

    integer i;
    string hex_file;

    initial begin
        for (i = 0; i < 16384; i = i + 1)
            RAM[i] = 32'd0;

        if (!$value$plusargs("HEX=%s", hex_file))
            hex_file = "test_alu.hex";

        $display("[DMEM] Loading HEX: %s", hex_file);
        $readmemh(hex_file, RAM);
	$display("[DMEM CHECK] RAM[3072] = %08h", RAM[3072]);
    end

    // =========================
    // READ
    // =========================
    always_comb begin
        case (funct3)

            // LB
            3'b000: begin
                case (A[1:0])
                    2'b00: RD = {{24{RAM[A[15:2]][7]}},  RAM[A[15:2]][7:0]};
                    2'b01: RD = {{24{RAM[A[15:2]][15]}}, RAM[A[15:2]][15:8]};
                    2'b10: RD = {{24{RAM[A[15:2]][23]}}, RAM[A[15:2]][23:16]};
                    2'b11: RD = {{24{RAM[A[15:2]][31]}}, RAM[A[15:2]][31:24]};
                endcase
            end

            // LH
            3'b001: begin
                if (A[1] == 1'b0)
                    RD = {{16{RAM[A[15:2]][15]}}, RAM[A[15:2]][15:0]};
                else
                    RD = {{16{RAM[A[15:2]][31]}}, RAM[A[15:2]][31:16]};
            end

            // LW
            3'b010: begin
                RD = RAM[A[15:2]];
            end

            // LBU
            3'b100: begin
                case (A[1:0])
                    2'b00: RD = {24'd0, RAM[A[15:2]][7:0]};
                    2'b01: RD = {24'd0, RAM[A[15:2]][15:8]};
                    2'b10: RD = {24'd0, RAM[A[15:2]][23:16]};
                    2'b11: RD = {24'd0, RAM[A[15:2]][31:24]};
                endcase
            end

            // LHU
            3'b101: begin
                if (A[1] == 1'b0)
                    RD = {16'd0, RAM[A[15:2]][15:0]};
                else
                    RD = {16'd0, RAM[A[15:2]][31:16]};
            end

            default: RD = RAM[A[15:2]];

        endcase
    end

    // =========================
    // WRITE
    // =========================
    always_ff @(posedge clk) begin
        if (we) begin

            case (funct3)

                // SB
                3'b000: begin
                    case (A[1:0])
                        2'b00: RAM[A[15:2]][7:0]   <= wd[7:0];
                        2'b01: RAM[A[15:2]][15:8]  <= wd[7:0];
                        2'b10: RAM[A[15:2]][23:16] <= wd[7:0];
                        2'b11: RAM[A[15:2]][31:24] <= wd[7:0];
                    endcase
                end

                // SH
                3'b001: begin
                    if (A[1] == 1'b0)
                        RAM[A[15:2]][15:0] <= wd[15:0];
                    else
                        RAM[A[15:2]][31:16] <= wd[15:0];
                end

                // SW
                3'b010: begin
                    RAM[A[15:2]] <= wd;
                end

                default: begin
                    RAM[A[15:2]] <= wd;
                end

            endcase
        end
    end

endmodule

