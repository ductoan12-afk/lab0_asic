#!/bin/bash

set -u

export PATH=/eda/tools/cadence/installs/XCELIUM2309/tools.lnx86/inca/bin/64bit:$PATH

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RTL_DIR="$BASE_DIR/rtl"
TB_DIR="$BASE_DIR/tb"
SW_DIR="$BASE_DIR/sw"
LOG_DIR="$BASE_DIR/logs"
COV_DIR="$BASE_DIR/coverage"

mkdir -p "$LOG_DIR" "$COV_DIR"
cd "$BASE_DIR/work"

export COV_DIR

# ============================================================
# 38 OFFICIAL TESTS
# ============================================================

PASS=0
FAIL=0
TIMEOUT=0

rm -f "$COV_DIR"/cov_bits_rv32ui-p-*.txt

for hex in "$SW_DIR"/rv32ui-p-*.hex; do

    name=$(basename "$hex" .hex)

    echo
    echo "------------------------------------------------------------"
    echo "TEST: $name"
    echo "HEX : $hex"
    echo "------------------------------------------------------------"

    rm -f "$COV_DIR/cov_bits_${name}.txt"

    xrun -64bit -sv \
        "$RTL_DIR"/*.sv \
        "$TB_DIR"/tb_rv32i_official.sv \
        "$TB_DIR"/rv32i_cov_tracker.sv \
        -top tb_rv32i_official \
        +HEX="$hex" \
        +COV_OUT="$COV_DIR/cov_bits_${name}.txt" \
        > "$LOG_DIR/trace_cov_${name}.txt" 2>&1

    if grep -q "\[TB\] RV32UI-P TEST PASSED" "$LOG_DIR/trace_cov_${name}.txt"; then
        echo "[PASS] $name"
        PASS=$((PASS+1))

    elif grep -q "TIMEOUT" "$LOG_DIR/trace_cov_${name}.txt"; then
        echo "[TIMEOUT] $name"
        TIMEOUT=$((TIMEOUT+1))

    else
        echo "[FAIL] $name"
        FAIL=$((FAIL+1))
    fi

done

# ============================================================
# 38 OFFICIAL TEST RESULT
# ============================================================

echo
echo "============================================================"
echo "       38 OFFICIAL TEST RESULT"
echo "============================================================"
echo "PASS    = $PASS / 38"
echo "FAIL    = $FAIL / 38"
echo "TIMEOUT = $TIMEOUT / 38"
echo "============================================================"

# ============================================================
# CALCULATE COVERAGE FROM 38 OFFICIAL TESTS
# ============================================================

echo
echo "Calculating coverage from 38 official tests..."

python3 - <<'PY'
import glob
import os

cov_dir = os.environ["COV_DIR"]
files = sorted(glob.glob(os.path.join(cov_dir, "cov_bits_rv32ui-p-*.txt")))

bits = [0] * 22

for f in files:
    with open(f) as fp:
        s = fp.read().strip()

    if len(s) != 22:
        continue

    for i, b in enumerate(s):
        if b == '1':
            bits[i] = 1

print("Coverage files =", len(files))

vector = ''.join(map(str, bits))
covered = sum(bits)
missing = [i for i, b in enumerate(bits) if b == 0]

print("38-test coverage =", vector)
print(f"38-test coverage = {covered}/22 = {covered/22*100:.2f}%")
print("Missing bins =", missing)
PY

# ============================================================
# DIRECTED COVERAGE TEST
# ============================================================

echo
echo "============================================================"
echo "       RUN DIRECTED TEST"
echo "============================================================"

rm -f "$COV_DIR/cov_bits_fwd_wb_stall.txt"
rm -f "$LOG_DIR/trace_final_fwd_wb_stall.txt"

xrun -64bit -sv \
    "$RTL_DIR"/*.sv \
    "$TB_DIR"/tb_rv32i_official.sv \
    "$TB_DIR"/rv32i_cov_tracker.sv \
    -top tb_rv32i_official \
    +HEX="$SW_DIR/cov_fwd_wb_stall.hex" \
    +COV_OUT="$COV_DIR/cov_bits_fwd_wb_stall.txt" \
    +DIRECTED_COV \
    > "$LOG_DIR/trace_final_fwd_wb_stall.txt" 2>&1

if grep -q "\[TB\] DIRECTED COVERAGE PASS" "$LOG_DIR/trace_final_fwd_wb_stall.txt" \
   && grep -q "ForwardA=01 StallD=1" "$LOG_DIR/trace_final_fwd_wb_stall.txt" \
   && [ -s "$COV_DIR/cov_bits_fwd_wb_stall.txt" ]; then

    echo "[PASS] Directed ForwardA=01 + StallD=1 coverage test"

else

    echo "[FAIL] Directed coverage test"

    grep -Ei "DIRECTED|ForwardA|StallD|COV_DEBUG|TEST FAILED|TIMEOUT|\*E|\*F" \
        "$LOG_DIR/trace_final_fwd_wb_stall.txt"

fi

# ============================================================
# FINAL COVERAGE
# ============================================================

echo
echo "============================================================"
echo "       FINAL COVERAGE"
echo "============================================================"

python3 - <<'PY'
import glob
import os

cov_dir = os.environ["COV_DIR"]

files = sorted(
    glob.glob(os.path.join(cov_dir, "cov_bits_rv32ui-p-*.txt"))
)

bits = [0] * 22

for f in files:
    with open(f) as fp:
        s = fp.read().strip()

    if len(s) != 22:
        continue

    for i, b in enumerate(s):
        if b == '1':
            bits[i] = 1

# Add directed coverage only if the directed test really
# generated the required condition and coverage file exists.
try:
    with open(os.path.join(os.path.dirname(cov_dir), "logs", "trace_final_fwd_wb_stall.txt")) as fp:
        trace = fp.read()
except FileNotFoundError:
    trace = ""

try:
    with open(os.path.join(cov_dir, "cov_bits_fwd_wb_stall.txt")) as fp:
        directed = fp.read().strip()
except FileNotFoundError:
    directed = ""

if "ForwardA=01 StallD=1" in trace and len(directed) == 22:
    for i, b in enumerate(directed):
        if b == '1':
            bits[i] = 1

vector = ''.join(map(str, bits))
covered = sum(bits)
missing = [i for i, b in enumerate(bits) if b == 0]

print("Coverage vector =", vector)
print("Covered bins    =", f"{covered} / 22")
print(f"Coverage        = {covered/22*100:.2f}%")
print("Missing bins    =", missing if missing else "None")

print()
print("============================================================")
print(f"       FUNCTIONAL COVERAGE = {covered/22*100:.2f}%")
print("============================================================")
PY
