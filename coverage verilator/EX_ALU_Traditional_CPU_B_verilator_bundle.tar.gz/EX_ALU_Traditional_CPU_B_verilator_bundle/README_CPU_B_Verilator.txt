Lab 4 CPU B - Traditional ALU, branch resolution at EX.

rtl/:
  Active CPU B RTL using the official38pass memory configuration.

tb/:
  tb_rv32i_official.sv
  rv32i_cov_tracker.sv

sw/:
  38 RV32UI architectural HEX files and two directed HEX files.

coverage/:
  rtl_only.vlt, for excluding testbench and tracker from RTL code coverage.

reference_memory_configs/:
  Archived official38pass and 10M memory configurations.
  These are references, not part of the active RTL compilation.

results_server_xcelium/:
  Previously recorded Xcelium logs and tracker-derived functional coverage.

Important:
  Xcelium test results are not Verilator code coverage.
  Re-run the tests on Pluto using Verilator and collect line, branch,
  expression and toggle coverage before comparing CPU A and CPU B.

No CPU A RTL or CPU A results are included in this bundle.
