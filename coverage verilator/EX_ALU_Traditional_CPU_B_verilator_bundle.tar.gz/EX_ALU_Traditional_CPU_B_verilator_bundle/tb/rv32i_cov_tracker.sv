module rv32i_cov_tracker (
    input logic       clk,
    input logic [1:0] forwardA,
    input logic [1:0] forwardB,
    input logic       stallD,
    input logic       PCSrcE
);

    // ============================================================
    // LAB 3 = 22 bins
    // ============================================================
    //
    // 0..2    : cp_fwd_a       (3)
    // 3..5    : cp_fwd_b       (3)
    // 6..7    : cp_stall       (2)
    // 8..9    : cp_redir       (2)
    // 10..15  : x_fwd_stall    (3 x 2 = 6)
    // 16..21  : x_fwd_redir    (3 x 2 = 6)
    //
    // TOTAL = 22
    // ============================================================

    bit hit [0:21];

    string out_file;
    integer fd;

    initial begin
        out_file = "cov_bits.txt";
        void'($value$plusargs("COV_OUT=%s", out_file));
    end

    always @(posedge clk) begin

        // cp_fwd_a
        case (forwardA)
            2'b00: hit[0] = 1'b1;
            2'b01: hit[1] = 1'b1;
            2'b10: hit[2] = 1'b1;
            default: ;
        endcase

        // cp_fwd_b
        case (forwardB)
            2'b00: hit[3] = 1'b1;
            2'b01: hit[4] = 1'b1;
            2'b10: hit[5] = 1'b1;
            default: ;
        endcase

        // cp_stall
        if (stallD === 1'b0)
            hit[6] = 1'b1;
        else if (stallD === 1'b1)
            hit[7] = 1'b1;

        // cp_redir
        if (PCSrcE === 1'b0)
            hit[8] = 1'b1;
        else if (PCSrcE === 1'b1)
            hit[9] = 1'b1;

        // x_fwd_stall = cp_fwd_a x cp_stall
        if ((forwardA <= 2) && !$isunknown(stallD))
            hit[10 + (forwardA * 2) + stallD] = 1'b1;

        // x_fwd_redir = cp_fwd_a x cp_redir
        if ((forwardA <= 2) && !$isunknown(PCSrcE))
            hit[16 + (forwardA * 2) + PCSrcE] = 1'b1;
	if (stallD)
	    $display("[COV_DEBUG] Rs1D=%02d Rs2D=%02d RdE=%02d Rs1E=%02d RdM=%02d RdW=%02d regwriteM=%b regwriteW=%b ForwardA=%b StallD=%b",
             dut.Datapath.Rs1D,
             dut.Datapath.Rs2D,
             dut.Datapath.RdE,
             dut.Datapath.Rs1E,
             dut.Datapath.RdM,
             dut.Datapath.RdW,
             dut.Datapath.regwriteM,
             dut.Datapath.regwriteW,
             forwardA,
             stallD);
    end

    final begin
        fd = $fopen(out_file, "w");

        if (fd != 0) begin
            for (integer i = 0; i < 22; i = i + 1)
                $fwrite(fd, "%0d", hit[i]);

            $fclose(fd);
        end
    end

endmodule
