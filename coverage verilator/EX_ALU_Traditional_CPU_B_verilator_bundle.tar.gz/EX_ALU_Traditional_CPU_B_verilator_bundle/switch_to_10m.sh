#!/bin/bash
set -e

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cp "$BASE_DIR/archive/memory_configs/Instruction_memory.sv.current_10m" \
   "$BASE_DIR/rtl/Instruction_memory.sv"

cp "$BASE_DIR/archive/memory_configs/Data_memory.sv.current_10m" \
   "$BASE_DIR/rtl/Data_memory.sv"

echo "[MEM] Switched to RANDOM-10M configuration"
echo "      Instruction_memory: 16M"
echo "      Data_memory:        64KB + DMEM_HEX"
