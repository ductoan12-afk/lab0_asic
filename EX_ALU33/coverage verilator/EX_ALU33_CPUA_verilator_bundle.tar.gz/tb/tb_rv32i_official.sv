`timescale 1ns / 1ps

module tb_rv32i_official;

    // ============================================================
    // DUT
    // ============================================================

    logic clk;
    logic reset;

    rv32i_top dut (
        .clk   (clk),
        .reset (reset)
    );

    rv32i_cov_tracker cov_tracker (
    .clk      (clk),
    .forwardA (dut.Datapath.ForwardA),
    .forwardB (dut.Datapath.ForwardB),
    .stallD   (dut.Datapath.StallD),
    .PCSrcE   (dut.PCSrcE)
	);

    // ============================================================
    // CLOCK
    // ============================================================

    always #5 clk = ~clk;

    bit directed_cov;

	initial begin
	    directed_cov = $test$plusargs("DIRECTED_COV");
	 end
        // ------------------------------------------------------------
	// Directed functional coverage test
	// End test immediately when ForwardA=01 and StallD=1 is observed
	// ------------------------------------------------------------
	always @(posedge clk) begin
	    if (directed_cov &&
	        (dut.Datapath.ForwardA === 2'b01) &&
	        (dut.Datapath.StallD === 1'b1)) begin

	        $display("[TB] DIRECTED COVERAGE PASS");
	        $display("[TB] ForwardA=01 StallD=1 observed");
	        $display("[TB] Directed coverage test finished");
                #1   $finish;
	    end
	end


    // ============================================================
    // TEST CONTROL
    // ============================================================

    integer cycles;
    integer timeout_cycles;

    bit test_done;
    bit test_pass;
    bit test_fail;

    // ============================================================
    // ECALL CONTROL
    // ============================================================

    integer ecall_delay;
    bit     ecall_pending;

    // ============================================================
    // COVERAGE
    // ============================================================
	
        // ============================================================
    // FUNCTIONAL COVERAGE - LAB 3
    // ============================================================

    covergroup cg_pipeline @(posedge clk);

        option.per_instance = 1;

        // --------------------------------------------------------
        // Forwarding A
        // 00 = NONE
        // 01 = WB
        // 10 = MEM
        // --------------------------------------------------------
        cp_fwd_a: coverpoint dut.Datapath.ForwardA {
            bins FWD_NONE = {2'b00};
            bins FWD_WB   = {2'b01};
            bins FWD_MEM  = {2'b10};
        }

        // --------------------------------------------------------
        // Forwarding B
        // --------------------------------------------------------
        cp_fwd_b: coverpoint dut.Datapath.ForwardB {
            bins FWD_NONE = {2'b00};
            bins FWD_WB   = {2'b01};
            bins FWD_MEM  = {2'b10};
        }

        // --------------------------------------------------------
        // Load-use stall
        // --------------------------------------------------------
        cp_stall: coverpoint dut.Datapath.StallD {
            bins NO_STALL = {1'b0};
            bins STALL    = {1'b1};
        }

        // --------------------------------------------------------
        // Redirect
        // --------------------------------------------------------
        cp_redir: coverpoint dut.PCSrcE {
            bins NO_REDIR = {1'b0};
            bins REDIR    = {1'b1};
        }

        // --------------------------------------------------------
        // Forwarding A x Stall
        // --------------------------------------------------------
        x_fwd_stall:
            cross cp_fwd_a, cp_stall;

        // --------------------------------------------------------
        // Forwarding A x Redirect
        // --------------------------------------------------------
        x_fwd_redir:
            cross cp_fwd_a, cp_redir;

    endgroup

    cg_pipeline cov;
    initial begin

        clk             = 1'b0;
        reset           = 1'b1;

        cycles          = 0;
        timeout_cycles  = 100000;

        test_done       = 1'b0;
        test_pass       = 1'b0;
        test_fail       = 1'b0;

        ecall_delay     = 0;
        ecall_pending   = 1'b0;

        // --------------------------------------------------------
        // Create coverage instance
        // --------------------------------------------------------

        cov = new();

        // --------------------------------------------------------
        // Reset
        // --------------------------------------------------------

        #20;
        reset = 1'b0;

        $display("");
        $display("========================================");
        $display("RV32I OFFICIAL TEST");
        $display("========================================");
        $display("PASS/FAIL protocol: ECALL (a7=93)");
        $display("");

    end

    // ============================================================
    // TEST MONITOR
    // ============================================================

    always @(negedge clk) begin

        if (!reset && !test_done) begin

            cycles = cycles + 1;

            #1;

            // ====================================================
            // ECALL DETECTION
            // ====================================================

            if (!ecall_pending &&
                dut.Datapath.InstrD === 32'h00000073) begin

                ecall_pending = 1'b1;
                ecall_delay   = 2;

                $display("[TB] ECALL detected - waiting for register WB");

            end

            // ====================================================
            // WAIT FOR REGISTER WRITEBACK
            // ====================================================

            if (ecall_pending) begin

                if (ecall_delay > 0) begin

                    ecall_delay = ecall_delay - 1;

                end

                else begin

                    $display("[TB] ECALL registers after WB");

                    $display("[TB] gp (x3)  = %08h",
                             dut.Datapath.Register_fileD.register[3]);

                    $display("[TB] a0 (x10) = %08h",
                             dut.Datapath.Register_fileD.register[10]);

                    $display("[TB] a7 (x17) = %08h",
                             dut.Datapath.Register_fileD.register[17]);

                    // =================================================
                    // TEST PASS
                    // =================================================

                    if ((dut.Datapath.Register_fileD.register[17] === 32'd93) &&
                        (dut.Datapath.Register_fileD.register[10] === 32'h00000000)) begin

                        test_pass = 1'b1;
                        test_done = 1'b1;

                        $display("[TB] ========================================");
                        $display("[TB] RV32UI-P TEST PASSED");
                        $display("[TB] ========================================");

                        $finish;

                    end

                    // =================================================
                    // TEST FAIL
                    // =================================================

                    else if ((dut.Datapath.Register_fileD.register[17] === 32'd93) &&
                             (dut.Datapath.Register_fileD.register[10] !== 32'h00000000)) begin

                        test_fail = 1'b1;
                        test_done = 1'b1;

                        $display("[TB] ========================================");
                        $display("[TB] RV32UI-P TEST FAILED");
                        $display("[TB] FAIL CODE = %08h",
                                 dut.Datapath.Register_fileD.register[10]);
                        $display("[TB] ========================================");

                        $finish;

                    end

                    // =================================================
                    // CONTINUE WAITING
                    // =================================================

                    else begin

                        ecall_delay = 1;

                    end

                end

            end

            // ====================================================
            // TIMEOUT
            // ====================================================

            if (cycles >= timeout_cycles) begin

                test_fail = 1'b1;
                test_done = 1'b1;

                $display("[TB] ========================================");
                $display("[TB] RV32UI-P TEST TIMEOUT");
                $display("[TB] CYCLES = %0d", cycles);
                $display("[TB] ========================================");

                $finish;

            end

        end

    end

endmodule
