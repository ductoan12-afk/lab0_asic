# D2  RV32UI-P Instruction Test Verification

## Scope
- CPU_A: EX_ALU33
- CPU_B: EX_ALU_Traditional
- CPU_C: ID_ALU33
- 38 test cases per CPU; 114 CPU-test results in total.

## Verified results
- CPU_A: 38 PASS, 0 FAIL, 0 TIMEOUT, 0 UNKNOWN
- CPU_B: 38 PASS, 0 FAIL, 0 TIMEOUT, 0 UNKNOWN
- CPU_C: 38 PASS, 0 FAIL, 0 TIMEOUT, 0 UNKNOWN
- Total: 114 PASS out of 114 results

## Evidence
- D2_test_matrix.csv: per-test result, input HEX hash, log hash and paths.
- D2_counts_summary.csv: aggregate results by CPU.
- CPU_A, CPU_B, CPU_C: archived input HEX files and trace logs.

## PASS classification
PASS is identified by the explicit log marker:
[TB] RV32UI-P TEST PASSED

FAIL and TIMEOUT are classified from their explicit markers.
The generic text "PASS/FAIL protocol" is not a result marker.

## Provenance note
These are the RV32UI-P tests packaged and run in the local lab repository.
This archive alone does not establish that every binary is byte-identical
to an untouched upstream riscv-tests release.

## Reproducibility
The CSV records source paths, archived log paths and SHA-256 values.
SHA256SUMS.txt records hashes for files in this snapshot, excluding itself.
