`timescale 1ns / 1ps

module tb_random_10m;

    // ------------------------------------------------------------
    // Configuration
    // ------------------------------------------------------------

    integer TARGET_INSTR;
    localparam integer MAX_EXTRA_INSTR = 2000;

    // ------------------------------------------------------------
    // Signature addresses
    //
    // Random program writes:
    //   0x83000700 = first signature word
    //   0x83000704 = second signature word
    // ------------------------------------------------------------

    localparam logic [31:0] SIGNATURE_ADDR  = 32'h83000700;
    localparam logic [31:0] SIGNATURE_ADDR2 = 32'h83000704;

    // Spike reference values
    localparam logic [31:0] REFERENCE_SIGNATURE1 = 32'hffb5b1c0;
    localparam logic [31:0] REFERENCE_SIGNATURE2 = 32'hb05a4700;

    // ------------------------------------------------------------
    // Clock / reset
    // ------------------------------------------------------------

    logic clk;
    logic reset;

    // ------------------------------------------------------------
    // DUT outputs
    // ------------------------------------------------------------

    logic [31:0] WriteDataM;
    logic [31:0] ALUresultM;
    logic        mem_writeM;

    // ------------------------------------------------------------
    // Signature
    // ------------------------------------------------------------

    logic [31:0] signature_value;
    logic [31:0] signature_value2;
    logic        signature_seen1;
    logic        signature_seen2;
    logic        result_done;

    // ------------------------------------------------------------
    // Instruction counter
    // ------------------------------------------------------------

    integer instr_count;
    integer executed_count;

    // CPI measurement
    integer cycle_count;
    integer cycle_at_10m;
    logic   measure_done;
    real    cpi_10m;

    // Shadow pipeline valid state
    logic validD;
    logic validE;
    logic validM;
    logic validW;

    // ------------------------------------------------------------
    // File
    // ------------------------------------------------------------

    integer fd;
    integer i;

    // ------------------------------------------------------------
    // DUT
    // ------------------------------------------------------------

    rv32i_top dut (
        .clk        (clk),
        .reset      (reset),
        .WriteDataM (WriteDataM),
        .ALUresultM (ALUresultM),
        .mem_writeM (mem_writeM)
    );

    // ------------------------------------------------------------
    // Clock
    // ------------------------------------------------------------

    initial begin
        clk = 1'b0;

        forever #5 clk = ~clk;
    end

    // ------------------------------------------------------------
    // Reset
    // ------------------------------------------------------------

    initial begin
        reset = 1'b1;

        repeat (5) @(posedge clk);

        reset = 1'b0;
    end

    // ------------------------------------------------------------
    // Configuration
    // ------------------------------------------------------------

    initial begin

        TARGET_INSTR = 10_000_000;

        if ($value$plusargs("TARGET_INSTR=%d", TARGET_INSTR)) begin
            $display("[TB] TARGET_INSTR = %0d",
                     TARGET_INSTR);
        end
        else begin
            $display("[TB] TARGET_INSTR default = %0d",
                     TARGET_INSTR);
        end

        $display("[TB] SIGNATURE_ADDR  = %08h",
                 SIGNATURE_ADDR);

        $display("[TB] SIGNATURE_ADDR2 = %08h",
                 SIGNATURE_ADDR2);

        $display("[TB] REFERENCE_SIGNATURE1 = %08h",
                 REFERENCE_SIGNATURE1);

        $display("[TB] REFERENCE_SIGNATURE2 = %08h",
                 REFERENCE_SIGNATURE2);

    end

    // ------------------------------------------------------------
    // Counters
    // ------------------------------------------------------------

    initial begin

        instr_count    = 0;
        executed_count = 0;

        cycle_count   = 0;
        cycle_at_10m  = 0;
        measure_done  = 1'b0;
        cpi_10m       = 0.0;

        validD = 1'b0;
        validE = 1'b0;
        validM = 1'b0;
        validW = 1'b0;

        signature_value  = 32'b0;
        signature_value2 = 32'b0;
        signature_seen1  = 1'b0;
        signature_seen2  = 1'b0;
        result_done      = 1'b0;

    end

    // ------------------------------------------------------------
    // ============================================================
    // CPI / RETIRED-INSTRUCTION MEASUREMENT
    // ============================================================

    always @(posedge clk) begin

        if (reset) begin

            cycle_count = 0;
            instr_count = 0;

            validD = 1'b0;
            validE = 1'b0;
            validM = 1'b0;
            validW = 1'b0;

        end
        else begin

            // One active clock cycle
            cycle_count = cycle_count + 1;

            // ----------------------------------------------------
            // Retire the instruction currently in WB.
            // validW represents a real instruction, not a bubble.
            // ----------------------------------------------------

            if (!measure_done && validW) begin

                instr_count = instr_count + 1;

                if ((instr_count % 1_000_000) == 0) begin

                    $display(
                        "[TB] RETIRED instructions = %0d  CYCLE = %0d  PC=%08h",
                        instr_count,
                        cycle_count,
                        dut.Datapath.PCF
                    );

                end

                if (instr_count == TARGET_INSTR) begin

                    measure_done = 1'b1;
                    cycle_at_10m = cycle_count;

                    cpi_10m =
                        (cycle_at_10m * 1.0) /
                        TARGET_INSTR;

                    $display("");
                    $display("==================================================");
                    $display("[CPI] 10 MILLION RETIRED INSTRUCTIONS REACHED");
                    $display("[CPI] INSTR_COUNT = %0d", instr_count);
                    $display("[CPI] CYCLE_COUNT = %0d", cycle_at_10m);
                    $display("[CPI] CPI         = %.6f", cpi_10m);
                    $display("==================================================");


                end
            end

            // -

            // Same behavior as reg_if_id:
            // CLR -> bubble
            // EN=0 -> hold
            // EN=1 -> capture instruction
            // ----------------------------------------------------

            if (dut.Datapath.FlushD)

                validD <= 1'b0;

            else if (!dut.Datapath.StallD)

                validD <= (dut.Datapath.InstrF != 32'b0);


            // ----------------------------------------------------
            // Shadow ID/EX validity.
            // FlushE inserts a bubble.
            // ----------------------------------------------------

            if (dut.Datapath.FlushE)

                validE <= 1'b0;

            else

                validE <= validD;


            // ----------------------------------------------------
            // EX/MEM
            // ----------------------------------------------------

            validM <= validE;


            // ----------------------------------------------------
            // MEM/WB
            // ----------------------------------------------------

            validW <= validM;


            // ----------------------------------------------------
            // Keep the old auxiliary executed counter.
            // This is NOT used as retired count.
            // ----------------------------------------------------

            if (dut.Datapath.regwriteE ||
                dut.Datapath.memwriteE ||
                dut.Datapath.branchE  ||
                dut.Datapath.jumpE) begin

                executed_count = executed_count + 1;

            end


            // ----------------------------------------------------
            // Safety limit
            // ----------------------------------------------------

            if (cycle_count > (TARGET_INSTR * 4)) begin

                $display("==================================================");
                $display("[TB] ERROR: cycle safety limit exceeded");
                $display("[TB] target retired = %0d", TARGET_INSTR);
                $display("[TB] retired         = %0d", instr_count);
                $display("[TB] cycles          = %0d", cycle_count);
                $display("[TB] executed        = %0d", executed_count);
                $display("==================================================");

                $finish;

            end
        end
    end

    always @(posedge clk) begin
            if (mem_writeM &&
                (ALUresultM == SIGNATURE_ADDR) &&
                !signature_seen1) begin

                signature_value = WriteDataM;
                signature_seen1 = 1'b1;

                $display("==================================================");
                $display("[TB] SIGNATURE1 STORE DETECTED");
                $display("[TB] SIGNATURE1_ADDR  = %08h",
                         SIGNATURE_ADDR);
                $display("[TB] SIGNATURE1_VALUE = %08h",
                         signature_value);
                $display("[TB] fetched_count    = %0d",
                         instr_count);
                $display("[TB] executed_count  = %0d",
                         executed_count);
                $display("==================================================");

                if (instr_count < TARGET_INSTR) begin

                    $display("[TB] TEST FAILED");
                    $display("[TB] Signature appeared before target.");
                    $display("[TB] target=%0d actual=%0d",
                             TARGET_INSTR,
                             instr_count);

                    $finish;

                end

            end

            // ----------------------------------------------------
            // SECOND signature word
            // 0x83000704
            //
            // IMPORTANT:
            // This is checked independently every clock.
            // No repeat/@posedge loop here.
            // ----------------------------------------------------

            if (mem_writeM &&
                (ALUresultM == SIGNATURE_ADDR2) &&
                !signature_seen2) begin

                signature_value2 = WriteDataM;
                signature_seen2  = 1'b1;

                $display("==================================================");
                $display("[TB] SIGNATURE2 STORE DETECTED");
                $display("[TB] SIGNATURE2_ADDR  = %08h",
                         SIGNATURE_ADDR2);
                $display("[TB] SIGNATURE2_VALUE = %08h",
                         signature_value2);
                $display("[TB] fetched_count    = %0d",
                         instr_count);
                $display("[TB] executed_count  = %0d",
                         executed_count);
                $display("==================================================");

            end

            // ----------------------------------------------------
            // Once both signature words are detected,
            // save architectural state and compare with Spike.
            // ----------------------------------------------------

            if (signature_seen1 && signature_seen2) begin

                result_done = 1'b1;

                // Allow pipeline state to settle.
                repeat (8) @(posedge clk);
                #1;

                // ------------------------------------------------
                // Save architectural register state
                // ------------------------------------------------

                fd = $fopen("work/sim/rtl_state.txt", "w");

                if (fd == 0) begin

                    $display("[TB] ERROR: cannot open");
                    $display("      work/sim/rtl_state.txt");

                    $finish;

                end

                $fwrite(fd,
                        "INSTR_COUNT %0d\n",
                        instr_count);

                $fwrite(fd,
                        "EXECUTED_COUNT %0d\n",
                        executed_count);

                $fwrite(fd,
                        "SIGNATURE1 %08h\n",
                        signature_value);

                $fwrite(fd,
                        "SIGNATURE2 %08h\n",
                        signature_value2);

                for (i = 0; i < 32; i = i + 1) begin

                    $fwrite(fd,
                            "x%0d %08h\n",
                            i,
                            dut.Datapath.Register_fileD.register[i]);

                end

                $fclose(fd);

                $display("[TB] RTL state written to:");
                $display("      work/sim/rtl_state.txt");

                // ------------------------------------------------
                // Compare full 64-bit signature with Spike
                // ------------------------------------------------

                if ((signature_value ==
                     REFERENCE_SIGNATURE1) &&
                    (signature_value2 ==
                     REFERENCE_SIGNATURE2)) begin

                    $display("==================================================");
                    $display("[TB] TEST PASSED");
                    $display("[TB] Full 64-bit signature matches Spike reference");
                    $display("[TB] RTL SIGNATURE1 = %08h",
                             signature_value);
                    $display("[TB] REF SIGNATURE1 = %08h",
                             REFERENCE_SIGNATURE1);
                    $display("[TB] RTL SIGNATURE2 = %08h",
                             signature_value2);
                    $display("[TB] REF SIGNATURE2 = %08h",
                             REFERENCE_SIGNATURE2);
                    $display("[TB] fetched_count   = %0d",
                             instr_count);
                    $display("[TB] executed_count = %0d",
                             executed_count);
                    $display("==================================================");

                end
                else begin

                    $display("==================================================");
                    $display("[TB] TEST FAILED");
                    $display("[TB] Signature mismatch against Spike reference");
                    $display("[TB] RTL SIGNATURE1 = %08h",
                             signature_value);
                    $display("[TB] REF SIGNATURE1 = %08h",
                             REFERENCE_SIGNATURE1);
                    $display("[TB] RTL SIGNATURE2 = %08h",
                             signature_value2);
                    $display("[TB] REF SIGNATURE2 = %08h",
                             REFERENCE_SIGNATURE2);
                    $display("==================================================");

                end

                $finish;

            end

    end
    // ------------------------------------------------------------
    // Timeout
    // ------------------------------------------------------------

    initial begin

        #400_000_000;

        $display("==================================================");
        $display("[TB] TIMEOUT");
        $display("[TB] fetched_count   = %0d",
                 instr_count);
        $display("[TB] executed_count = %0d",
                 executed_count);
        $display("==================================================");

        $finish;

    end


endmodule
