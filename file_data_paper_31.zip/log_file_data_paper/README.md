Scientific Paper - Test Data Archive

Purpose:
Store test sources, build artifacts, test images, raw logs,
coverage reports and summary data for scientific paper preparation.

Rules:
- Preserve original logs and previous results.
- Record the design configuration and tool version for each run.
- Use identical test inputs when comparing CPU configurations.
- Keep raw data separate from processed summaries.
- Do not modify CPU RTL merely to facilitate testing.
